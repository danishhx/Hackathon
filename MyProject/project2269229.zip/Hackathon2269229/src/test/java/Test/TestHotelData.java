package Test;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import HotelData.HotelData;
import io.github.bonigarcia.wdm.WebDriverManager;

public class TestHotelData 
{
	private WebDriver driver;
	@BeforeTest
	public void setupDriver() 
	{
		WebDriverManager.edgedriver().setup();
		driver = new EdgeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(180,TimeUnit.SECONDS);
	}
		  	

    @Test
    public void openWebsite() {
        driver.get("https://www.tripadvisor.in/");
    }

 

    @Test(dependsOnMethods = "openWebsite")
    public void clickHolidayHomes() {
        HotelData hotelData = new HotelData(driver);
        hotelData.clickHolidayHomes();
    }

 

    @Test(dependsOnMethods = "clickHolidayHomes")
    public void searchLocation() throws InterruptedException {
        HotelData hotelData = new HotelData(driver);
        hotelData.searchLocation("Nairobi");
    }

 

    @Test(dependsOnMethods = "searchLocation")
    public void clickNairobi() throws InterruptedException {
        HotelData hotelData = new HotelData(driver);
        hotelData.clickNairobi();
        hotelData.scroll();
    }
    
    @Test(dependsOnMethods = "clickNairobi")
    public void scrolling() throws InterruptedException {
        HotelData hotelData = new HotelData(driver);
        hotelData.scroll();
    }
    
    

 

    @Test(dependsOnMethods = "scrolling")
    public void selectDateRange() throws InterruptedException {
        HotelData hotelData = new HotelData(driver);
        hotelData.selectDateRange();
    }
    
    @Test(dependsOnMethods = "selectDateRange")
    public void inDate() throws InterruptedException 
    {
    	 HotelData hotelData = new HotelData(driver);
    	 hotelData.checkIn();
    }
    @Test(dependsOnMethods = "selectDateRange")
    public void outDate() throws InterruptedException 
    {
    	 HotelData hotelData = new HotelData(driver);
    	 hotelData.checkOut();
    }


    @Test(dependsOnMethods ="outDate")
    public void guestClick()
    {
    	HotelData hotelData=new HotelData(driver);
    	hotelData.guestclick();
    }

    @Test(dependsOnMethods = "guestClick")
    public void increaseGuests() throws InterruptedException {
        HotelData hotelData = new HotelData(driver);
        hotelData.increaseGuests();
    }
    
    @Test(dependsOnMethods = "increaseGuests")
    public void tripadvisor() 
    {
        HotelData hotelData = new HotelData(driver);
        hotelData.tripadvisor();
    }
    
    @Test(dependsOnMethods = "tripadvisor")
    public void travelrating() 
    {
        HotelData hotelData = new HotelData(driver);
        hotelData.travelrating();
    }
    
    @Test(dependsOnMethods = "travelrating")
    public void liftaccess() throws InterruptedException 
    {
    	 HotelData hotelData = new HotelData(driver);
         hotelData.elevator();
    }
    
    @Test(dependsOnMethods="liftaccess")
    public void details() throws InterruptedException
    {
    	 HotelData hotelData = new HotelData(driver);
         hotelData.hotelDetails();
    }
    
    @AfterTest
    public void afterTest() {
        driver.quit();
    }
}
