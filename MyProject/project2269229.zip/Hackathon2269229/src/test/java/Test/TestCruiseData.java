package Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;
import CruiseShip.CruiseData;

public class TestCruiseData 
{
	  private WebDriver driver;
	  
	  @BeforeTest
	    public void setupDriver() {
	        WebDriverManager.edgedriver().setup();
	        driver = new EdgeDriver();
	        driver.manage().window().maximize();
	      
	    }
	  	
	  @Test
	    public void openWebsite()
	  	{
	        driver.get("https://www.tripadvisor.in/");
	    }
	  
	  @Test(dependsOnMethods = "openWebsite")
	    public void clickHolidayHomes() {
	        CruiseData cd= new CruiseData(driver);
	        cd.clickHolidayHomes();
	    }
	
	  @Test(dependsOnMethods = "clickHolidayHomes")
	    public void searchLocation() throws InterruptedException {
		  CruiseData cd= new CruiseData(driver);
	      cd.searchLocation("Nairobi");
	    }
	  
	  @Test(dependsOnMethods = "searchLocation")
	    public void clickNairobi() {
		  CruiseData cd= new CruiseData(driver);
	      cd.clickNairobi();
	    }
	  

	    @Test(dependsOnMethods = "clickNairobi")
	    public void cruiseClick() 
	    {
	    	 CruiseData cd= new CruiseData(driver);
	         cd.cruiseClick();
	    }
	    
	    @Test(dependsOnMethods = "cruiseClick")
	    public void cruiseSelect() throws InterruptedException 
	    {
	    	 CruiseData cd= new CruiseData(driver);
	         cd.cruiseline();
	    }
	    @Test(dependsOnMethods = "cruiseSelect")
	    public void cruiseclick() throws InterruptedException 
	    {
	    	 CruiseData cd= new CruiseData(driver);
	         cd.selectcruise();
	    }
	    @Test(dependsOnMethods = "cruiseclick")
	    public void shipButton() 
	    {
	    	 CruiseData cd= new CruiseData(driver);
	         cd.selectShipButton();
	    }
	    @Test(dependsOnMethods = "shipButton")
	    public void selectShip () throws InterruptedException 
	    {
	    	 CruiseData cd= new CruiseData(driver);
	         cd.selectShip();
	    }
	    @Test(dependsOnMethods = "selectShip")
	    public void search() throws InterruptedException 
	    {
	    	 CruiseData cd= new CruiseData(driver);
	         cd.searchButton();
	    }
	    
	    @Test(dependsOnMethods = "search")
	    public void scrolling() throws InterruptedException
	    {
	    	 CruiseData cd= new CruiseData(driver);
	    	 cd.scroll();
        }
	    @Test(dependsOnMethods = "scrolling")
	    public void windowhandling() throws InterruptedException
	    {
	    	 CruiseData cd= new CruiseData(driver);
	    	 cd.windowHandle();
	    }
	    @Test(dependsOnMethods = "windowhandling")
	    public void shipDetails() throws InterruptedException
	    {
	    	 CruiseData cd= new CruiseData(driver);
	    	 cd.shipDetails();
	    }
	    @Test(dependsOnMethods = "shipDetails")
	    public void languages() throws InterruptedException
	    {
	    	 CruiseData cd= new CruiseData(driver);
	    	 cd.languages();;
	    }
	    
	    @AfterTest
	    public void afterTest() 
	    {
	        driver.quit();
	    }


}
