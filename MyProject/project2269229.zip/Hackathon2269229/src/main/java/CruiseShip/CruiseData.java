package CruiseShip;

import java.time.Duration;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;

public class CruiseData {
    private WebDriver driver;


    public  CruiseData(WebDriver driver) 
    {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    @FindBy(xpath = "//span[contains(text(),'Holiday Homes')]")
    private WebElement holidayHomes;

    @FindBy(css = "div[class='slvrn Z0 Wh rsqqi EcFTp GADiy'] input[placeholder='Where to?']")
    private WebElement searchInput;

    @FindBy(xpath = "//div[@class='biGQs _P fiohW fOtGX'][normalize-space()='Nairobi']")
    private WebElement nairobiOption;
    
    @FindBy(xpath = "//span[normalize-space()='Cruises']")
    private WebElement cruiseClick;
    
    @FindBy(xpath = "//span[normalize-space()='Cruise line']")
    private WebElement cruiseline;
    
    @FindBy(xpath = "//span[contains(text(),'1A Vista Reisen')]")
    private WebElement selectcruise;
    
    @FindBy(xpath = "//button[@aria-label='Cruise ship: Chekov']//span[@class='biGQs _P fOtGX'][normalize-space()='Chekov']")
    private WebElement selectcruiseShip;
    
    @FindBy(xpath = "//span[contains(text(),'Mekong Prestige II')]")
    private WebElement selectship;
    
   // @FindBy(xpath = "//button[contains(text(),'Search')]")
    @FindBy(css="button[class='rmyCe _G B- z _S c Wc wSSLS w AeLHi sOtnj ymEbx']")
    private WebElement search;
    
    @FindBy(xpath="//*[@id=\"ship_overview\"]/div/div/div/div[1]/div[1]/div[2]/div[1]")
    private WebElement passengerCrew;
    
    @FindBy(xpath="//*[@id=\"ship_overview\"]/div/div/div/div[1]/div[1]/div[2]/div[3]")
    private WebElement year;
    
    @FindBy(xpath="//span[@class='ZmySZ q']")
    private List<WebElement> lang;
    
   
    public void clickHolidayHomes() {
        holidayHomes.click();
    }

    public void searchLocation(String location) throws InterruptedException {
        searchInput.sendKeys(location);
        Thread.sleep(2000);
    }
    
    public void clickNairobi() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        WebElement searchButton = wait.until(ExpectedConditions.elementToBeClickable(nairobiOption));
        searchButton.click();
    }
    
    public void cruiseClick()
    {
    	cruiseClick.click();   
    }
    
    public void cruiseline()
    {
    	cruiseline.click();
    }
    
    public void selectcruise()
    {
    	selectcruise.click();
    }
    public void selectShipButton()
    {
    	selectcruiseShip.click();
    }
    public void selectShip()
    {
    	selectship.click();
    }
    public void searchButton() throws InterruptedException
    {
    	Thread.sleep(3000);
    	search.click();
    }
    public void scroll()
    {
    	 JavascriptExecutor js = (JavascriptExecutor)driver;
         js.executeScript("window.scrollBy(0,document.body.scrollHeight);");
    }
    public void windowHandle() throws InterruptedException
    {
	    Thread.sleep(4000);
        Set<String> window=driver.getWindowHandles();
        for(String handles:window)
        {
            driver.switchTo().window(handles);
        }
       
        
    }
    public void shipDetails() throws InterruptedException
    {
    	Thread.sleep(4000);   
    	System.out.println(passengerCrew.getText());
    	System.out.println("Launched Year "+ year.getText());
    }
    public void languages() throws InterruptedException
    {
    	Thread.sleep(4000);
        System.out.println("The lanugages offered are:");
        for(int l=0;l<lang.size();l++)
        {
            WebElement ele4=lang.get(l);
            if(l>0)
            {
            System.out.println(ele4.getText());
            }
        }
    }
}

