package HotelData;
import java.time.Duration;
import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;

public class HotelData 
{
    private WebDriver driver;

    public HotelData(WebDriver driver) 
    {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//span[contains(text(),'Holiday Homes')]")
    private WebElement holidayHomes;

    @FindBy(css = "div[class='slvrn Z0 Wh rsqqi EcFTp GADiy'] input[placeholder='Where to?']")
    private WebElement searchInput;

    @FindBy(xpath = "//div[@class='biGQs _P fiohW fOtGX'][normalize-space()='Nairobi']")
    private WebElement nairobiOption;
 
    @FindBy(css = "button[aria-label='Enter the date range.'] span[class='biGQs _P fiohW uWleQ']")
    private WebElement dateRange;

    @FindBy(xpath = "//div[@aria-label='20 June 2023']")
    private WebElement checkInDate;


    @FindBy(xpath = "//div[@aria-label='25 June 2023']")
    private WebElement checkOutDate;

    @FindBy(css="div[class='yzRfM f'] div:nth-child(1)")
    private WebElement guestButton;

    @FindBy(css = "div[class='ZSTqW f u Wg vfszC'] button[title='increase'] svg")
    private WebElement increaseGuestsButton;
    
    @FindBy(css = "div[class='NBkgc f'] span[class='biGQs _P ttuOS']")
    private WebElement applyButton;

    @FindBy(css ="button[aria-label='Tripadvisor Sort: Tripadvisor Sort'] span[class='biGQs _P vvmrG']")
    private WebElement tripadvisorClick;
    
    @FindBy(css = "span[id='menu-item-TRAVELERRATINGHIGH'] span[class='biGQs _P fOtGX']")
    private WebElement travelerratingSelect;

    @FindBy(css = "div[id=':component_2-R1l9icl:'] div[class='biGQs _P ttuOS']")
    private WebElement amenities;
    
    @FindBy(css ="label[for='amenities.27'] span[class='PMWyE _W I j u R2 _S']")
    private WebElement elevator;
    
    @FindBy(css ="div[data-button-type='primary'] span[class='biGQs _P ttuOS']")
    private WebElement elevatorApply;
    
    @FindBy(css="div[class='iCUJC b']")
    private List<WebElement> hotelPrices;
    
    @FindBy(css=".ToVyw.b.S7.W.o.q[href]")
    private List<WebElement> hotelName;
    
    @FindBy(css="div.MvXmI")
    private List<WebElement> totalAmount;
    
    public void clickHolidayHomes() {
        holidayHomes.click();
    }

    public void searchLocation(String location) throws InterruptedException {
        searchInput.sendKeys(location);
        Thread.sleep(2000);
    }

    public void clickNairobi() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        WebElement searchButton = wait.until(ExpectedConditions.elementToBeClickable(nairobiOption));
        searchButton.click();
       
    }

    public void scroll()
    {
    	JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,100)");
    }
	

    public void selectDateRange() throws InterruptedException
    {
    	Thread.sleep(3000);
    	dateRange.click();
    }
    
    public void checkIn() throws InterruptedException
    {
    	Thread.sleep(2000);
    	checkInDate.click();
    }
    public void checkOut() throws InterruptedException
    {
    	Thread.sleep(2000);
    	checkOutDate.click();
    }

    public void guestclick()
    {
    	guestButton.click();
    }

    public void increaseGuests() throws InterruptedException 
    {
    	Thread.sleep(2000);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        WebElement increaseButton = wait.until(ExpectedConditions.elementToBeClickable(increaseGuestsButton));
        increaseButton.click();
        increaseButton.click();
        applyButton.click();
    }  
    
    public void tripadvisor()
    {
    	tripadvisorClick.click();
    }
    public void travelrating()
    {
    	travelerratingSelect.click();
    }
    
    public void elevator() throws InterruptedException 
    {
    	Thread.sleep(3000);
    	amenities.click();
    	elevator.click();
    	elevatorApply.click();
    }
    public void hotelDetails() throws InterruptedException
    {
    	for(int i=0;i<3;i++)
        {
           
                WebElement ele=hotelPrices.get(i);
                WebElement ele1=hotelName.get(i);
                WebElement ele2= totalAmount.get(i);
                System.out.println("Hotel price per day for "+ (i+1) +" hotel is "+ ele.getText());
                System.out.println((i+1)+" Hotel name is "+ele1.getText());
                System.out.println("The amount of the "+(i+1)+ "hotel is "+ ele2.getText());
           
        }
    }
}